//
//  main.m
//  RFCOMM_Open_SPP_Example
//
//  Created by Marco Pontil on 12/18/04.
//  Copyright Apple Computer, Inc. 2004. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
